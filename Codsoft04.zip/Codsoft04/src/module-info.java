/**
 * 
 */
/**
 * 
 */
module Codsoft04 {
	requires java.desktop;
}