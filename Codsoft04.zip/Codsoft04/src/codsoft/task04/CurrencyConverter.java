package codsoft.task04;

import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class CurrencyConverter {

	public static void main(String[] args) {
		Currency currency=new Currency();

	}

}

class Currency extends JFrame{
	JLabel l;
	JButton b;
	JTextField t;
	
	public Currency() {
		setTitle("Currency Converter");
		setSize(400,600);
		setLayout(new FlowLayout());
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		l=new JLabel("-------------------------Currency Converter------------------------------");
		add(l);
		
		
		b=new JButton("START");
		add(b);
		
		b.addActionListener(e->getCurrency());
			
		revalidate();
		repaint();
	}

	public void getCurrency() {
		add(new JLabel("       From (USD, INR, EUR)?"));
        JTextField tfFromCurrency = new JTextField(5);
        add(tfFromCurrency);

        add(new JLabel("        Enter amount:"));
        JTextField tfAmount = new JTextField(10);
        add(tfAmount);

        add(new JLabel("                 To (USD, INR, EUR)?"));
        JTextField tfToCurrency = new JTextField(5);
        add(tfToCurrency);

        b = new JButton("Convert");
        add(b);

	    b.addActionListener(e -> {
	        String text = tfAmount.getText().trim();
	        try {
	            Integer value =Integer.parseInt(text);
	            converter(tfFromCurrency,tfAmount,tfToCurrency);
	        } catch (NumberFormatException nfe) {
	            add(new JLabel("Invalid Input"));
	            revalidate();
	            repaint();
	        }
	    });
	    
	    
	    setVisible(true);
	    revalidate();
	    repaint();
		
		
	}

	public void converter(JTextField tfFromCurrency,JTextField tfAmount,JTextField tfToCurrency) {
		String fromCurrency=tfFromCurrency.getText().trim().toUpperCase();
		String toCurrency=tfToCurrency.getText().trim().toUpperCase();
		double amount=0;
		
		try {
			amount=Double.parseDouble(tfAmount.getText().trim());
		}catch(NumberFormatException e) {
			l=new JLabel("Invalid Input");
			add(l);
			
			revalidate();
			repaint();
		}
		
		double result=0;
		if(fromCurrency.equals("USD")) {
			if(toCurrency.equals("INR")) {
				result=amount*83.0;
			}
			else if(toCurrency.equals("EUR")) {
				result=amount*0.91;
			}
			else {
				result=amount;
			}
		}
		
		if(fromCurrency.equals("INR")) {
			if(toCurrency.equals("USD")) {
				result=amount/83.0;
			}
			else if(toCurrency.equals("EUR")) {
				result=amount/0.91;
			}
			else {
				result=amount;
			}
		}
		
		if(fromCurrency.equals("EUR")) {
			if(toCurrency.equals("INR")) {
				result=amount*91.0;
			}
			else if(toCurrency.equals("USD")) {
				result=amount/0.91;
			}
			else {
				result=amount;
			}
		}
		
		l=new JLabel("Result:  "+result);
		add(l);
		
		revalidate();
		repaint();
		
	}
	
}