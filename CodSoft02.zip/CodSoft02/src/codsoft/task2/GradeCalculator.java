package codsoft.task2;

import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class GradeCalculator {

	public static void main(String[] args) {
		Calculator c=new Calculator();

	}

}

class Calculator extends JFrame{
	
	JLabel l;
	JTextField t;
	JButton b;
	JButton grade;
	
	private JTextField[] ta = new JTextField[6];

	
	public Calculator() {
	setTitle("Grade_Calculator");
	setSize(800,600);
	setLayout(new FlowLayout());
	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	setVisible(true);
	
	l=new JLabel("Enter student marks:");
	add(l);
	
	for(int i=0;i<6;i++) {
	ta[i]=new JTextField(5);
	add(ta[i]);
	
	setVisible(true);
	}
	
	
	b=new JButton("Add");
	add(b);
	
	b.addActionListener(e->calculate());
	
    setVisible(true);
	
	}
	
	public void calculate() {
		int[] marks = new int[6];
		int add=0;
		for (int i=0;i<6;i++) {
		    try {
		        marks[i]=Integer.parseInt(ta[i].getText());
		        add=add+marks[i];
		    } catch (NumberFormatException ex) {
		        marks[i]=0;
		    }
		}
		
		double average=add/6;
		l.setText("Addition is: "+add+" Average is: "+average);
		
		if (grade== null) {
            grade= new JButton("Show Grade");
            add(grade);
            grade.addActionListener(e -> gradeCalculation(average));
            revalidate();
            repaint();
        }
		
	}
	
	public void gradeCalculation(double avg) {
		String Grade;
        if (avg >= 90) Grade = "A+";
        else if (avg >= 80) Grade = "A";
        else if (avg >= 70) Grade = "B";
        else if (avg >= 60) Grade = "C";
        else if (avg >= 50) Grade = "D";
        else Grade = "F";

        l.setText("Grade is: "+Grade);
        add(l);
        
        revalidate();
        repaint();
	}
	
	
	}
	
