/**
 * 
 */
/**
 * 
 */
module CodSoft02 {
	requires java.desktop;
}