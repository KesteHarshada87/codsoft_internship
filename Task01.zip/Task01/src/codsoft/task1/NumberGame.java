package codsoft.task1;

import java.util.Scanner;
import java.util.InputMismatchException;


public class NumberGame {

	public static void main(String[] args) {
		System.out.println("----Instructions----");
		System.out.println("You are allow to enter numbers between 1 to 100..");
		System.out.println("You can attempt 5 times..");
		System.out.println();
		
		System.out.println("Let's begin the game!!");
		System.out.println("If you want to play game press 1 else press 0..");
		Scanner sc=new Scanner(System.in);
		int choice=sc.nextInt();
		if(choice==1) {
			Game g=new Game();
			g.game();
		}
		else {
			System.out.println();
		}
	
		System.out.println();
		while(choice==1) {
		System.out.println();	
		System.out.println("*******************************"); 
		System.out.println("Are you want to play again?");
		System.out.println("If yes press 1 else press 0..");
		int choiceNew=sc.nextInt();
		if(choiceNew==1) {
			Game g=new Game();
			g.game();
		}
		else {
			System.out.println("Game over!!");
			choice=0;
		}
		}
		
	}

}
