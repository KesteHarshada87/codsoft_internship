package codsoft.task1;

import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

public class Game {
	public void game() {
		Random rand=new Random();
		int target=rand.nextInt(100);
		int score=1000;
	for(int j=0;j<5;j++) {
			System.out.println();
			
			Scanner sc=new Scanner(System.in);
			try {
			System.out.println("Guess the number:");
			int num=sc.nextInt() ;
			
			if(num==target) {
				System.out.println();
				System.out.println("Congratulations!! You win the game..");
				System.out.println("Game over!!");
				System.out.println("Your score is: "+score);
				return;
			}
			
			else {
				score=score-100;
				for(int k=1;k<=10;k++) {
				if(num-k==target || num+k==target) {
				System.out.println("You are very close target..");
				System.out.println("Try again!");
				
				}
				}
				
				if(num<target-11) {
					System.out.println("Your guess is too low from target..");
					System.out.println("Try again!");
					
				}
				
				if(num>target+11) {
					System.out.println("Your guess is too high from target..");
					System.out.println("Try again!");
				}
				
			}
			
		}
		catch(InputMismatchException e){
			System.out.println("Please enter integer!!");
			score=score-100;
			j--;
		}
		
	}


	}

}